package com.malik.restfulcrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestfulcrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestfulcrudApplication.class, args);
	}

}
